package jl2755.ast;


public interface Expr {
	public void prettyPrintNode();
}