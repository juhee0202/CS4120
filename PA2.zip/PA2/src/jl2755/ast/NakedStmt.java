package jl2755.ast;


public interface NakedStmt {
	public void prettyPrintNode();
}
