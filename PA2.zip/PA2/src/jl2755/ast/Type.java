package jl2755.ast;


public interface Type {
	public void prettyPrintNode();
}