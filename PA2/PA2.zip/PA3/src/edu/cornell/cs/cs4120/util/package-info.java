/**
 * Common utilities.
 */
package edu.cornell.cs.cs4120.util;