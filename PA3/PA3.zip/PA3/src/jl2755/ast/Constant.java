package jl2755.ast;

public interface Constant extends Expr {
	public void prettyPrintNode();
}
