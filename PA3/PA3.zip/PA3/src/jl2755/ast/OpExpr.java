package jl2755.ast;

public interface OpExpr extends Expr {
	public void prettyPrintNode();
}
