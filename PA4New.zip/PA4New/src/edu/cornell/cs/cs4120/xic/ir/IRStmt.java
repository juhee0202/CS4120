package edu.cornell.cs.cs4120.xic.ir;

/**
 * An intermediate representation for statements
 */
public abstract class IRStmt extends IRNode {
}
