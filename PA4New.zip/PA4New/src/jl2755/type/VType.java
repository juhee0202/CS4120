package jl2755.type;

public interface VType {
	public boolean equals(Object o);
	public String toString();
}
