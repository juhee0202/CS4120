
public class doh {

	public static void main (String[]args) {
		int[] array = {1};
		System.out.println(array[-1]);
	}
}
