package jl2755.assembly;

public enum ChildType {
	CONSTANTOFFSET,
	CONSTANTFACTOR,
	REGISTERBASE,
	REGISTERFACTOR;
}
