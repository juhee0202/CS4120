
public abstract class TestingEquals {
	@Override
	public boolean equals(Object o) {
		return true;
	}
}
