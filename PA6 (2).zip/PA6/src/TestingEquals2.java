
public abstract class TestingEquals2 extends TestingEquals{

	@Override
	public abstract boolean equals(Object o);
}
