
public class TestingEquals3 extends TestingEquals2{

	@Override
	public boolean equals(Object o) {
		return false;
	}

}
