package jl2755.controlflow;

import java.util.List;
import edu.cornell.cs.cs4120.xic.ir.IRStmt;

public interface OptimizationGraph {
	public void print();
}
